<header id="entete">
				<div class="row">
					<div class="col-sm-4 ">
						<a href="index.html"> <img src="interface/img/logo.png" id="logo" /></a>
					</div>
					<div class="col-sm-8" >
						<h1 class="color-white text-shadow " id="titre-appli"> SYSTEME DE GESTION UNIVERSITAIRE </h1>
					</div>
				</div>

			</header>