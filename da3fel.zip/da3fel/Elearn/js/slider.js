
	var slideIndex = 1;
	showSlides(slideIndex);

	// Next/previous controls
	function plusSlides(n) {
	  showSlides(slideIndex += n);
	}

	// Thumbnail image controls
	function currentSlide(n) {
	  showSlides(slideIndex = n);
	}

	function showSlides(n) {
	  var i;
	  var slides = document.getElementsByClassName("mySlides");
	  //var suiv = document.getElementsByClassName("")
	  //var dots = document.getElementsByClassName("dot");
	  switch(n)
	  {
	  	case 1:
	  		$('.prev').hide();
	  		break;
	  	case 3:
	  		$('.next').hide();
	  		break;
	  	default:
	  		$('.prev').show();
	  		$('.next').show();
	  		break;
	  }
	  if (n >= slides.length) 
	  {
		$(".next").hide();
	  	n = slides.length;
		 
	  }
	  /*else{
	  	$('.next').hide();
	  }//Corriger ici
	  if(slideIndex==slides.length)
	  {
	  	$(".next").hide();
	  	$(".prev").show();
	  }else{
	  	if(slideIndex==1)
	  	{
	  		$(".next").show();
	  		$(".prev").hide();
	  	}else{$(".next").show();
	  $(".prev").show();}
	  }*/

	  if (n < 1) {
	  slideIndex = 1;//slides.length;
	  $(".next").show();
	  }//Corriger ici
	  for (i = 0; i < slides.length; i++) {
	      slides[i].style.display = "none";
	  }
	 /* for (m = 0; i < dots.length; m++) {
	      dots[i].className = dots[m].className.replace(" active", "");
	  }*/
	  slides[slideIndex-1].style.display = "block";
	 //dots[slideIndex-1].className += " active";
	}


