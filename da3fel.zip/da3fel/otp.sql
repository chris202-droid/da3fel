-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Lun 23 Août 2021 à 22:09
-- Version du serveur :  5.7.11
-- Version de PHP :  7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `otp`
--

-- --------------------------------------------------------

--
-- Structure de la table `question`
--

CREATE TABLE `question` (
  `IDQUESTION` bigint(4) NOT NULL,
  `IDUSER` bigint(4) NOT NULL,
  `QUESTION` char(255) DEFAULT NULL,
  `REPONSE` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `IDUSER` bigint(4) NOT NULL,
  `NOM` varchar(255) DEFAULT NULL,
  `PRENOM` varchar(255) DEFAULT NULL,
  `LOGIN` longtext,
  `PASS` longtext,
  `TEL` longtext,
  `EMAIL` varchar(255) DEFAULT NULL,
  `DATENAISS` date DEFAULT NULL,
  `LIEUNAISS` varchar(255) DEFAULT NULL,
  `Genre` varchar(5) NOT NULL DEFAULT 'U',
  `bloque` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`IDUSER`, `NOM`, `PRENOM`, `LOGIN`, `PASS`, `TEL`, `EMAIL`, `DATENAISS`, `LIEUNAISS`, `Genre`, `bloque`) VALUES
(1, 'Nteme', 'christophe', 'chris', 'chris', '656451234', 'christophenteme@gmail.com', NULL, NULL, 'M', 0),
(26, 'Eloundou', 'Pierre', 'yes', 'yes', '652316125', 'ddadas@gmail.com', '2021-08-01', NULL, 'F', 0),
(28, 'Mbouna', 'patrick', 'pat', 'pat', '694163455', 'patrickmbouna@gmail.com', '2021-09-01', NULL, 'M', 0);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`IDQUESTION`),
  ADD KEY `FK_QUESTION_USER` (`IDUSER`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`IDUSER`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `IDUSER` bigint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
