<?php


	function SendTwilioSMS($number,$sms)
	{
		
		// Your Account SID and Auth Token from twilio.com/console
		// To set up environmental variables, see http://twil.io/secure
		$account_sid = 'AC156d1208c8c8901c3b5a5e974a99cf49' ;
		$auth_token = 'c206a98a148b08654ec5a1482aa4663d';
		// In production, these should be environment variables. E.g.:
		// $auth_token = $_ENV["TWILIO_AUTH_TOKEN"]
		// A Twilio number you own with SMS capabilities
			$twilio_number = "+16467620345";
			$tel = $number;

		$client = new Client($account_sid, $auth_token);
		$client->messages->create(
		    // Where to send a text message (your cell phone?)
		    $tel,
		    array(
		        'from' => $twilio_number,
		        'body' => $sms
		    )
		);
		return 1;
	}

	function VerifUser($username,$userpass)
	{
			
			if(isset($username)&& isset($userpass))
			{
				$NomUtilisateur = htmlspecialchars($username);
				$Mot2Pass = htmlspecialchars($userpass);
				if(isset($NomUtilisateur)&&isset($Mot2Pass))
				{
					//$Mot2Pass = $public->encrypt(password_hash($Mot2Pass, PASSWORD_DEFAULT));
					//$NomUtilisateur = $public->encrypt($NomUtilisateur);
					$user = $bd->SelectToConnect($NomUtilisateur,$Mot2Pass);
					
					if(sizeof($user)==1)
					{
						$otp1 = $otp->getOtp($Mot2Pass)->at($maintenant);
						$tel =$user[0]->tel;// $private->decrypt();
						$vrai = SendTwilioSMS("+237$tel","Utilisez ce code $otp1 pour vous authentifier");
						
						if($vrai==1) return 1;

					}else{return 0;}
				}else{return 0;}
				
			}
			else{
				
				return -1;

			}
		
	}
	

	function ValidOTP($otp,$decalage,$pass)
	{
		
			if(isset($otp))
			{
				$otpUser = htmlspecialchars($otp);
				if($otp->checkOTP($otpUser,$decalage,$Mot2Pass)==True)
				{
					header ("location: ../rino");
		    			echo "<meta http-equiv='refresh' content='0; url = ../readline_info()' />";
		    			session_start();
		    			//$_SESSION['id'] = $tel;
		    			//$_SESSION['user'] = $NomUtilisateur;
		    			//$_SESSION['count'] = 0;
		    			return 1;
				}else{}

			}
	}
	

	$Mot2Pass = "";
		
	$otp = new OTP();
	$decalage = 0;
	$maintenant = time()+$decalage;
	

	if(isset($_POST['validuser']))
	{
		$username = $_POST['username'];
		$apass = $_POST['apass'];
		$result = VerifUser($username,$apass);
		if($result==1)
		{
			echo "OKOKOKO";

		}
	}


?>