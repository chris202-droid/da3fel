<?php 

		 require '../OwnFaceAPI/Recognize.php';
  $recognize = new Recognize();
  $temps = 600;
  $cpt = 0;
  $cpt2 = 0;
  $user = $bd->SelectForSession($id);
  do {
    $path = "../OwnFaceAPI/img/658945221/";
    $python = "../OwnFaceAPI";
    $result = $recognize->RecognizeEvaluation($path,$python,"tmp");
    $cpt2++; //compte le nombre de capture total
    if($result>=2)
    {
      $cpt++;//nombre de reconnaissance faite
    }
    if($cpt2==3)
    {
      if(($cpt/$cpt)<0.6)
      {
        $rslt = $bd->Bloque($id);//bloquage de l'utilisateur
        break;
      }
      break;
    }

    //$_SESSION['count'] += 1;
    sleep($temps);
    $temps  = random_int(300, 600);
  } while ( $cpt2<3);


 ?>