<?php 
echo  '<br>';
echo  '<br>';
echo  '<br>';
echo  '<br>';
echo  '<br>';
echo  '<br>';
echo $_POST['nom']; 
echo $_POST['prenom'];?>