				<div class="corps" >
					<marquee direction="left">
						<h1>Bienvenue sur le portail de Gestion de l'Université </h1>
					</marquee>
					<div class="border border-radius " id="cadre_logo">
						<div id="cadre" >
							<img src="interface/img/logoUY1.png" width="300px" height="350px" />
						</div>
						
							<div class=" margin-left-70" id="group-bouton">
							<button id="btn-connexion" class="bouton border-radius" >
								<span class="glyphicon glyphicon-off"> </span><a href="index.php?page=connexion"></a> Connexion
							</button>
							<button id="btn-preinscription" class="connect bouton border-radius" >
								<span class="glyphicon glyphicon-pencil"> </span><a href="index.php?page=inscription"></a> Inscription
							</button>
							
							</div>
						
						
					</div>
				</div>

				