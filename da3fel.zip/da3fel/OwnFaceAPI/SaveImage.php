<?php 

	$baseFromJavascript = $_POST['base64'];
	if(isset($baseFromJavascript))
	{
		$baseToPhp = explode(',',$baseFromJavascript);
		$data = base64_decode($baseToPhp[1]);
		$nbr = rand(1,1000);
		$path = "img/tmp$nbr.png";
		file_put_contents($path, $data);
		$_POST['base64'] = "";
	}
	
	echo exec('python test.py tmp$nbr.png tmp.png');


 ?>