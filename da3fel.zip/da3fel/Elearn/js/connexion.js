
			$(document).ready(function() {
				
				$('.otpConnect').hide();
				$('.next').click(function(){
					var username = $("#username").val();
					var apass = $("#apass").val();
					if((username!=null)&&(apass!=null))
					{
						alert(username);
						alert(apass);
						$.ajax({
							url: 'js/admin/connexion.php',
							type: 'post',
							dataType: 'html',
							data: {
								username:username,
								apass:apass
							},
							success: function (data) {
								//console.log(data);
								$('.result').html(data).show();
								alert(data);
							},
							error: function(){
								//$('.result').html(data).show();
								//console.log(data);
								alert('Echec');
							}
						});
					}
				});
				
			});

