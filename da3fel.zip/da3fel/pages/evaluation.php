<html class="no-js" lang="fr">
  <!--<![endif]-->
  <head>
    <meta charset="utf-8">

    <!-- Use the .htaccess and remove these lines to avoid edge case issues.
    More info: h5bp.com/b/378 -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

    <title>Accueil</title>
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Mobile viewport optimized: j.mp/bplateviewport -->
    <meta name="viewport" content="width=device-width,initial-scale=1">

    <!-----------------------Liens CSS --------------------------->
    <link rel="stylesheet" type="text/css" href="../RINO/lui/css/menu.css">
    <link rel="shortcut icon" href="../interface/img/favicon.png"/>
    <link rel="stylesheet" href="../interface/css/style.css">
    <link rel="stylesheet" href="../interface/css/bootstrap.css">
    <link rel="stylesheet" href="../interface/css/bootstrap.min.css">
    <link rel="stylesheet" href="../interface/js/wizard/wizard.css">
    <link rel="stylesheet" href="../interface/js/jquery-steps/jquery.steps.css">
    <script type="text/javascript" src="../assets/js/jquery.js"></script>
    <!---------------  Script JS---------------->
  </head>

  <body id="page-top">

    <div class="content">
      <?php include 'navbar.php'; ?>

    </div>
    

  <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>
  </body>

</html>



<script type="text/javascript">
/*
var interval = 60000;
function Envoie(){
  var telephone = 2;
            
            $.ajax({
              url: '../OwnFaceAPI/eval.php',
              type: 'post',
              dataType: 'html',
              data: {
                telephone:telephone
              },
              success: function (data) {
                alert("reussi");
                //console.log(data);
                $('#result').html(data).show();
              },
              error: function(){
                alert('Echec');
              }
            });
}

//Envoie();
function entierAleatoire(min, max)
{
  return Math.floor(Math.random()(max-min+1))+min;
}
var mnt = setInterval("entierAleatoire(6,15)",2000);
alert(mnt);
 $("#exam").click(function(){
    alert("Go...");
    var mnt = setInterval("entierAleatoire(6,15)",interval*5);
    var result = setInterval("Envoie()",interval*mtn);
    alert("Finish...");
  });*/


</script>

  