import numpy as numpy
import cv2
import matplotlib.pyplot as plt
from os import listdir
import sys
import face_recognition
from PIL import Image


#plt.imshow(test_image_gray,cmap='gray')

def FaceDetection(image):
	#Chargement de l'image
	test_image = cv2.imread(image)
	test_image_gray = cv2.cvtColor(test_image,cv2.COLOR_BGR2GRAY)
	#chargement et detection des visages
	haar_cascade_face = cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
	faces_rects = haar_cascade_face.detectMultiScale(test_image_gray,scaleFactor=1.2,minNeighbors=5);
	#print('Faces found:',len(faces_rects))
	#dessin de rectangle sur des visages
	#for (x,y,w,h) in faces_rects:
		#cv2.rectangle(test_image,(x,y),(x+w,y+h),(0,255,0),2)
	#fonction de transformation de l'image
	#plt.imshow(convertToRGB(test_image))

	return len(faces_rects)

def convertToRGB(image):
	return cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)


def Face(img):
	image = face_recognition.load_image_file(img)
	face_locations  = face_recognition.face_locations(image)

	return face_locations

def ImageIsCorrect(img):
	nombre_face = FaceDetection(img)
	tableau_face = len(Face(img))

	if (nombre_face==1):
		if(tableau_face==1):
			return tableau_face
	else:
		return -1

photo = sys.argv[1]
#photo2 = sys.argv[2]
#for photo in listdir('img/'):


print(ImageIsCorrect(photo))

#plt.show()
