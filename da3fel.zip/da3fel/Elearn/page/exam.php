 
 <div class="container" style="color: black;">
   
    
      
     <div class="container exam">
        <div class="row">
          
          <div class="col-md-9">
            <h5 class="h3">Répondre Aux questions...</h5>
            <div class="container" style="color: black;">
              <div class="rquiz-multichoice container-fluid" lang="fr">
                  <h2 id="rquiz-multichoice">Questions A Choix Multiples</h2>
                  <p>The following questions can have more than one correct answer!</p>
                  <p>Who discovered America? (Christopher Columbus)(!Marco Polo)(!James Cook)</p>
                  <p>Which animal is a mammal? (!shark)(whale)(kangaroo)(!coal tit)(mouse)(!bee)</p>
                  <p>Alexander The Great was (!Persian) (!Greek) (Macedonian) (!Arab) (!Egyptian)</p>
              </div>
      
              <div class="rquiz-multichoice container-fluid" lang="fr">
                  <h2 id="rquiz-multichoice">Vrai ou Faux</h2>
                  <p>The following questions can have more than one correct answer!</p>
                  <p>Who discovered America? (Faux)(!Vrai)</p>
                  <p>Which animal is a mammal? (!Faux)(Vrai)</p>
                  <p>Alexander The Great was (!Faux) (Vrai) </p>
              </div>
            </div>
          </div>

          <div class="col-md-3">
            <div class="row">
              <div class="col-md-12 bg-primary" style="border-radius: 5px black;">
                
              </div>

              <div class="col-md-12">
                <center><?php echo "<img class='img img-rounded bg-success' src='../OwnFaceAPI/img/$id/$id.jpg' style='width:8em; height: 8em; border-radius: 8em;align-self: center;'>"; ?></center>
              </div>
              <div class="col-md-12">
                <h5 class="h6">Nom: <?php echo $user[0]->nom ?></h5>
              </div>
              <div class="col-md-12">
                <h5 class="h6">Prenom: <?php echo $user[0]->prenom ?></h5>
              </div>
              <div class="col-md-12">
                <h5 class="h6">E-mail: <?php echo $user[0]->email ?></h5>
              </div>
              <div class="col-md-12">
                <h5 class="h6">Tel: <?php echo $user[0]->tel ?></h5>
              </div>
              <div class="col-md-12 bg-primary rec" style="border-radius: 5px black;">
                
              </div>
            </div>
          </div>

        </div>
      </div>
   </div>