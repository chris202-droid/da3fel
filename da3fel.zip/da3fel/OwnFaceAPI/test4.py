import cv2
import numpy
import math

imagePath = 'img/tmp1.jpg'
processedPath = 'img/processed.jpg'
outputPath = 'img/out.jpg'

threshold = 0.3

outwidth = 800
outheight = 800
iepx = outwidth/2.0
iepy = outheight*1.0/4.0
intereyesdistance = 200 # final number of pixel between eyes

# Create the haar cascade
eyeGauche = cv2.data.haarcascades+'haarcascade_mcs_lefteye.xml'
eyeDroit = cv2.data.haarcascades+'haarcascade_mcs_righteye.xml'
bouche = cv2.data.haarcascades+'haarcascade_mcs_mouth.xml'

leCascade = cv2.CascadeClassifier(eyeGauche)
reCascade = cv2.CascadeClassifier(eyeDroit)
mouthCascade = cv2.CascadeClassifier(bouche)

def findRightEye(image):
    # Detect left eyes in the image
    righteyes = reCascade.detectMultiScale(
        image,
        scaleFactor=1.2,
        minNeighbors=5,
        minSize=(80, 50),
        flags = cv2.COLOR_BGR2GRAY
    )
    return righteyes

def findLeftEye(image):
    # Detect left eyes in the image
    lefteyes = leCascade.detectMultiScale(
        image,
        scaleFactor=1.2,
        minNeighbors=5,
        minSize=(80, 50),
        flags = cv2.COLOR_BGR2GRAY
    )
    return lefteyes

def findMouth(image):
    # Detect mouthes in the image
    mouthes = mouthCascade.detectMultiScale(
        image,
        scaleFactor=1.2,
        minNeighbors=5,
        minSize=(80, 50),
        flags = cv2.COLOR_BGR2GRAY
    )
    return mouthes

# Read the image
image = cv2.imread(imagePath)
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

outsize = max(image.shape[:2])

imagedebug = image.copy()

righteyes = findRightEye(gray)
print('found '+str(len(righteyes))+' right eye (green)')
print(righteyes)
for (x, y, w, h) in righteyes:
    cv2.rectangle(imagedebug, (x, y), (x+w, y+h), (0, 255, 0), 10) # Draw a rectangle around the eye

lefteyes = findLeftEye(gray)
print('found '+str(len(lefteyes))+' left eyes (blue)')
print(lefteyes)
for (x, y, w, h) in lefteyes:
    cv2.rectangle(imagedebug, (x, y), (x+w, y+h), (255, 0, 0), 10) # Draw a rectangle around the eye

mouthes = findMouth(gray)
print('found '+str(len(mouthes))+' mouth (red)')
print(mouthes)
for (x, y, w, h) in mouthes:
    cv2.rectangle(imagedebug, (x, y), (x+w, y+h), (0, 0, 255), 10) # Draw a rectangle around the mouth

cv2.imshow("Faces found" ,imagedebug)
cv2.imwrite(processedPath, imagedebug)
cv2.waitKey(0)

for (xre, yre, wre, hre) in righteyes:
    for (xle, yle, wle, hle) in lefteyes:
        for (xmo, ymo, wmo, hmo) in mouthes:
            cxre = xre+wre/2.0 # x position of right eye center
            cyre = yre+hre/2.0 # y position of right eye center
            cxle = xle+wle/2.0 # x position of left eye center
            cyle = yle+hle/2.0 # y position of left eye center
            cxmo = xmo+wmo/2.0 # x position of mouth center
            cymo = ymo+hmo/2.0 # y position of mouth center
            dxrl = math.sqrt(pow((cxre)-(cxle),2)+pow((cyre)-(cyle),2)) # distance between right eye and left eye
            dxlm = math.sqrt(pow((cxle)-(cxmo),2)+pow((cyle)-(cymo),2)) # distance between left eye and mouth
            dxmr = math.sqrt(pow((cxmo)-(cxre),2)+pow((cymo)-(cyre),2)) # distance between mouth and right eye
            print(str(dxrl)+' '+str(dxlm)+' '+str(dxmr))
            if (abs(dxmr/dxlm - 1) < threshold) and (abs(dxlm/dxrl - 1) < threshold) and (abs(dxrl/dxmr - 1) < threshold) and cxre > cxle and cymo > cyle and cymo > cyre:
                angle = math.degrees(numpy.arctan((cyre-cyle)/(cxre-cxle)))
                #print angle
                rot_mat = cv2.getRotationMatrix2D(((cxre+cxle)/2,(cyre+cyle)/2),angle,intereyesdistance/dxrl)
                #print rot_mat
                rot_mat[0][2] += iepx-(cxre+cxle)/2
                rot_mat[1][2] += iepy-(cyre+cyle)/2
                image = cv2.warpAffine(image, rot_mat, (outwidth,outheight),flags=cv2.INTER_LINEAR)
                cv2.imshow("Image processed" ,image)
                cv2.imwrite(outputPath, image)
                cv2.waitKey(0)