
			<footer class="background-color-blue" id="pied">
				<h4 class="text-align-center color-white padding-10 text-shadow">copyright 2017</h4>
			</footer>