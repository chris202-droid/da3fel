import http.client

conn = http.client.HTTPSConnection("microsoft-face1.p.rapidapi.com")

payload = {
    "\"url\": \"http://example.com/1.jpg\""
}

headers = {
    'content-type': "application/json",
    'x-rapidapi-key': "990bb2bf48mshc15b2ab8f1fb8c0p1d46cfjsn514594761f1f",
    'x-rapidapi-host': "microsoft-face1.p.rapidapi.com"
    }

conn.request("POST", "/detect?returnFaceId=true&recognitionModel=recognition_01&detectionModel=detection_01&returnFaceAttributes=age", payload, headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))
