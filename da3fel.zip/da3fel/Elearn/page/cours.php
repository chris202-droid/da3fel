<div class="container" style="color: black;">
	<h1 class="h1">Cours</h1> <hr style="color: black; width: 4px;">
</div>
