    
    
<div class="container" >
	

		<h6 class="h6" style="color: black;">Cliquez sur le bouton ci-dessous pour commencer l'examen...</h6>
		
			<form class="form-group" method="post" action="index.php?page=exam.php">
				<a href="index.php?page=exam.php"><button class="btn btn-primary bouton exa" name="exa">Commencer</button></a>
			</form>
      	
	

      
</div>

   