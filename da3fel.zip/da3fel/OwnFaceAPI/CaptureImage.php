<!DOCTYPE html>
<html>
<head>
  <title></title>
  <script type="text/javascript" src="../assets/js/jquery.js"></script>
</head>
<body>
<div id="yes"></div>
  <script type="text/javascript">
  var o = 0;
    $(document).ready(function(){
      setTimeout(function(){
        //$('#yes').load('essaie.php');
        alert(o++);
      },1000);
      //continue;
      
    });
  </script>
  <?php 

    function setInterval($f,$milsec)
    {
      $sec = ((int)$milsec)/1000;
      while(true)
      {
        $f();
        sleep($sec);
      }
    }
    function yes()
    {
      echo "Bonjour<br>";
    }
    $yes = "yes";
    setInterval($yes,1000);


   ?>
</body>
</html>
