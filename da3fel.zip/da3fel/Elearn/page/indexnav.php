 <div class="div sticky-top">
	   	<nav class="nav sticky-top navbar navbar-light bg light navbar-expand-lg bg-primary">
			<a class="navbar-brand rino" style=" color: white;">DA-3FEL</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportContent" aria-controls="navbarSupportContent" arial-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
			<div class="collapse navbar-collapse" id="navbarSupportContent">
				<center>
					<ul class="nav justify-content-end nav-tabs">

				      <li class="nav-item  menu_nav"> <a class="nav-link" href="index.php?page=inscription.php" style=" color: white;"> Inscription</a> </li>

				      <li class="nav-item  menu_nav"> <a class="nav-link" href="index.php?page=connexion.php" style=" color: white;"> Connexion</a> </li>
				</ul>
				</center>
				
			</div>
		</nav>
   </div> <i class="glyphicon glyphicon-user form-control-feedback"></i>