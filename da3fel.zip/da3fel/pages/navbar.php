


    <div class="navbar navbar-fixed-top" style="background-color: #4dc9fa; ">
      <div class="row container-fluid m-auto" style="height: 5em;">
        <div class="col-md-2">
          
        </div>
        <div class="col-md-8">
          <button class="btn btn-default" style="border:auto;">Examen</button>
        </div>
        <div class="col-md-2" style=" color: white;">
         
        </div>
      </div>
    </div>
    <div class="container-fluid" style="background-color:#e02d99; border-top:10em;">
      <nav class="navbar navbar-light bg light navbar-expand-lg" >
        <a class="navbar-brand rino" style=" color: white;">RINO</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportContent" aria-controls="navbarSupportContent" arial-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarSupportContent">
          <ul class="navbar-nav m-auto">
            hksjdfksdhfksd
          </ul>
        </div>
      </nav>
    </div>
