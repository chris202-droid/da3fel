    
    
<div class="container" >
	

		<h6 class="h6" style="color: black;">Cliquez sur le bouton ci-dessous pour commencer l'examen...</h6>
      		<a href="index.php?page=exam.php"><button class="btn btn-primary bouton exa" name="exa">Commencer</button></a>
	

      
</div>
<script type="text/javascript">
  $(document).ready(function(){
    $('.exa').click(function(){
      var oui = 1;
      $.ajax({
        url: 'eval.php',
              type: 'post',
              dataType: 'html',
              data: {
                oui:oui
              },
              success: function (data) {
                console.log(data);
                //$('#result').html(data).show();
                alert("Bravo!!!");
                alert(data);
              },
              error: function(){
                alert('Echec');
              }
      });
    });
  });
</script>
   