<?php 

  $page = "cours.php";
  $pages = scandir("page/");
  if(isset($_GET['page']) && !empty($_GET['page']) && in_array($_GET['page'],$pages )){
    $page = $_GET['page'];
  }
  
?>

<?php 
  
  function Go()
  {
    require 'Recognize.php';
  $recognize = new Recognize();
    $tel = '100986';//$_SESSION['id'];
  $path = "img/$tel/";

  /*$reslt = $recognize->RecognizeEvaluation($path,"tmp");
  if($reslt>0)
  {
    echo "<h4>Visage Reconnu: $reslt</h4>";
    ///$_SESSION['count'] +=1;
  }else{echo "<h4>Visage Non Reconnu</h4>";}
  
  */

  $reslt = z($path,"nteme","armel");
  if($reslt>0)
  {
    echo "<h4>Visage Reconnu: $reslt</h4>";
    ///$_SESSION['count'] +=1;
  }else{echo "<h4>Visage Non Reconnu</h4>";}
  }
  





 ?>

<!DOCTYPE html>
<html>
<head>
	<title>DA-3FEL</title>
	<link rel="stylesheet" href="css/slider.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="page/rquiz/src/css/quiz.css">
    <script type="text/javascript" src="../js/slider.js"></script>
    <script type="text/javascript" src="../assets/js/jquery.js"></script>
    <script type="text/javascript" src="../assets/js/bootstrap.js"></script>
    <script type="text/javascript" src="page/rquiz/rquiz/rquiz.js"></script>
</head>
	

<body>
	<?php include 'page/navbar.php' ?>
	<?php include "page/$page"; ?>
</body>

</html>
